package com.cg.loanapplication.dto;

import javax.persistence.Column;

public class LoanProgramsOffered {

	public LoanProgramsOffered() {
		
	}
	
	@Column(name="ProgramName")
	String programName;
	@Column(name="description")
	String description;
	@Column(name="type")
	String type;
	@Column(name="durationinyears")
	int durationInyears;
	@Column(name="minloanamounts")
	double minLoanAmount;
	@Column(name="maxloanamounts")
	double maxLoanAmount;
	@Column(name="rateofinterest")
	int rateOfInterest;
	@Column(name="proofs_required")
	String proofsRequired;
	public String getProgramName() {
		return programName;
	}
	public void setProgramName(String programName) {
		this.programName = programName;
	}
	public String getdescription() {
		return description;
	}
	public void setdescription(String description) {
		this.description = description;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public int getDurationInyears() {
		return durationInyears;
	}
	public void setDurationInyears(int durationInyears) {
		this.durationInyears = durationInyears;
	}
	public double getMinLoanAmount() {
		return minLoanAmount;
	}
	public void setMinLoanAmount(double minLoanAmount) {
		this.minLoanAmount = minLoanAmount;
	}
	public double getMaxLoanAmount() {
		return maxLoanAmount;
	}
	public void setMaxLoanAmount(double maxLoanAmount) {
		this.maxLoanAmount = maxLoanAmount;
	}
	public int getRateOfInterest() {
		return rateOfInterest;
	}
	public void setRateOfInterest(int rateOfInterest) {
		this.rateOfInterest = rateOfInterest;
	}
	public String getProofsRequired() {
		return proofsRequired;
	}
	public void setProofsRequired(String proofsRequired) {
		this.proofsRequired = proofsRequired;
	}
	public LoanProgramsOffered(String programName, String description,
			String type, int durationInyears, double minLoanAmount,
			double maxLoanAmount, int rateOfInterest, String proofsRequired) {
		super();
		this.programName = programName;
		this.description = description;
		this.type = type;
		this.durationInyears = durationInyears;
		this.minLoanAmount = minLoanAmount;
		this.maxLoanAmount = maxLoanAmount;
		this.rateOfInterest = rateOfInterest;
		this.proofsRequired = proofsRequired;
	}
	@Override
	public String toString() {
		return "LoanProgramsOffered [programName=" + programName
				+ ", description=" + description + ", type=" + type
				+ ", durationInyears=" + durationInyears + ", minLoanAmount="
				+ minLoanAmount + ", maxLoanAmount=" + maxLoanAmount
				+ ", rateOfInterest=" + rateOfInterest + ", proofsRequired="
				+ proofsRequired + "]";
	}
}
