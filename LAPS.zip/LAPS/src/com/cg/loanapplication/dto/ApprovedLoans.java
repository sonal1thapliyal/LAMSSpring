package com.cg.loanapplication.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;



@Entity
@Table(name="ApprovedLoans")
public class ApprovedLoans {

	public ApprovedLoans() {

	}
	@Id
	@Column(name="Application_ID")
	@NotNull(message="Application Id cannot be empty")
	int applicationID;
	@Column(name="Customer_name")
	@NotEmpty(message="Name cannot be empty")
	String customerName;
	@Column(name="amountofloangranted")
	double amountOfLoanGranted;
	@Column(name="monthlyinstallment")
	double monthlyInstallment;
	@Column(name="yearstimeperiod")
	int yearsTimePeriod;
	@Column(name="downpayment")
	double downPayment;
	@Column(name="rateofinterest")
	int rateOfInterest;
	@Column(name="totalamountpayable")
	double totalAmountPayable;
	
	public int getApplicationID() {
		return applicationID;
	}
	public void setApplicationID(int applicationID) {
		this.applicationID = applicationID;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public double getAmountOfLoanGranted() {
		return amountOfLoanGranted;
	}
	public void setAmountOfLoanGranted(double amountOfLoanGranted) {
		this.amountOfLoanGranted = amountOfLoanGranted;
	}
	public double getMonthlyInstallment() {
		return monthlyInstallment;
	}
	public void setMonthlyInstallment(double monthlyInstallment) {
		this.monthlyInstallment = monthlyInstallment;
	}
	public int getYearsTimePeriod() {
		return yearsTimePeriod;
	}
	public void setYearsTimePeriod(int yearsTimePeriod) {
		this.yearsTimePeriod = yearsTimePeriod;
	}
	public double getDownPayment() {
		return downPayment;
	}
	public void setDownPayment(double downPayment) {
		this.downPayment = downPayment;
	}
	public int getRateOfInterest() {
		return rateOfInterest;
	}
	public void setRateOfInterest(int rateOfInterest) {
		this.rateOfInterest = rateOfInterest;
	}
	public double getTotalAmountPayable() {
		return totalAmountPayable;
	}
	public void setTotalAmountPayable(double totalAmountPayable) {
		this.totalAmountPayable = totalAmountPayable;
	}
	public ApprovedLoans(int applicationID, String customerName,
			double amountOfLoanGranted, double monthlyInstallment,
			int yearsTimePeriod, double downPayment, int rateOfInterest,
			double totalAmountPayable) {
		super();
		this.applicationID = applicationID;
		this.customerName = customerName;
		this.amountOfLoanGranted = amountOfLoanGranted;
		this.monthlyInstallment = monthlyInstallment;
		this.yearsTimePeriod = yearsTimePeriod;
		this.downPayment = downPayment;
		this.rateOfInterest = rateOfInterest;
		this.totalAmountPayable = totalAmountPayable;
	}
	@Override
	public String toString() {
		return "ApprovedLoans [applicationID=" + applicationID
				+ ", customerName=" + customerName + ", amountOfLoanGranted="
				+ amountOfLoanGranted + ", monthlyInstallment="
				+ monthlyInstallment + ", yearsTimePeriod=" + yearsTimePeriod
				+ ", downPayment=" + downPayment + ", rateOfInterest="
				+ rateOfInterest + ", totalAmountPayable=" + totalAmountPayable
				+ "]";
	}
	

}
